<?php 
namespace IDGdashboard\Controllers;
/*
 * File: Account.php
 * Project: Controllers
 * Created Date: Fr Dec 2021
 * Author: Ayatulloh Ahad R
 * Email: ayatulloh@indiega.net
 * Phone: 085791555506
 * -----
 * Last Modified: Sun Dec 05 2021
 * Modified By: Ayatulloh Ahad R
 * -----
 * Copyright (c) 2021 Indiega Network
 * -----
 * HISTORY:
 * Date      	By	Comments
 * ----------	---	---------------------------------------------------------
 */

class Account extends Dashboard
{
    
    public function __construct() {
        
        parent::__construct();
        $this->filename     = 'account';

        // $this->addMenuData = [
        //     [
        //         'url'   => '/as',
        //         'label' => 'wkwkwk',
        //         'icon'  => 'fas fa-home',
        //     ]
        // ];

    }

    public function custom($url = 'asd', $label = 'qweqweqwe', $icon = 'asd')
    {
        return  parent::custom('lalala', 'lalala', 'lalala');
    }    
    
}
