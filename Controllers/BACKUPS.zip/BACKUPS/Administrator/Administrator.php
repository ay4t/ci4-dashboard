<?php 
namespace IDGdashboard\Controllers\Administrator;

use IDGdashboard\Controllers\Dashboard;

class Administrator extends Dashboard
{
    # code...
}