<?php 
namespace IDGdashboard\Controllers;

/*
 * File: Dashboard.php
 * Project: Controllers
 * Created Date: Th Dec 2021
 * Author: Ayatulloh Ahad R
 * Email: ayatulloh@indiega.net
 * Phone: 085791555506
 * -----
 * Last Modified: Sun Dec 05 2021
 * Modified By: Ayatulloh Ahad R
 * -----
 * Copyright (c) 2021 Indiega Network
 * -----
 * HISTORY:
 * Date      	By	Comments
 * ----------	---	---------------------------------------------------------
 * 
 * IMPORTANT: 
 * THIS PACKAGE REQUIRE IONAUTH libraries by Ben Edmunds
 * 
 */

use IDGdashboard\Models\User;
use IonAuth\Libraries\IonAuth;
use App\Controllers\BaseController;
use IDGdashboard\Config\InitAssets;
use IDGdashboard\Models\SettingModel;
use IDGdashboard\Config\DashboardConfig;
use IDGdashboard\Libraries\SidebarMenu\MenuBuilder;


class Dashboard extends BaseController
{

    protected $data;

    protected $user;

    protected $user_group;

    protected $config;

    protected $ionAuth;

    protected $menuBuilder;
    
    public $filename;
    public $addMenuData = [];

    public function __construct() {

        /** load Codeigniter helper */
        helper('html', 'url');

        /** init ionAuth libraries */
        $this->ionAuth  = new IonAuth;
        $this->config   = new DashboardConfig;
        $this->menuBuilder = new MenuBuilder;

        /** create init Asset CSS and JS */
        $this->createInitAssets();

        /** loading User Model */
        $this->user     = new User();

        $this->user_group   = 2;

        /** init Meta pages */
        $this->data['title'] = 'Dashboard';
        $this->data['config'] = $this->config;
        
        
    }

    public function custom( $url = 'asd', $label = 'asd', $icon = 'asd' )
    {
        return $this->menuBuilder->addNew($url, $label, $icon);
    }

    

    /**
     * undocumented function summary
     *
     * @param Type $var Description
     * @return type
     * @throws conditon
     * @author Ayatulloh Ahad R - ayatulloh@indiega.net
     **/
    public function renderLayouts( $className = '' )
    {
        
        /** 
         * validate user must be logged in
         * note: Dikarenakan fungsi ini tidak bisa di gunakan di constructor maka kita buatkan disini 
         **/
        if( ! $this->ionAuth->loggedIn() ) return redirect()->to('/auth/login');

        /**
         * membuat nama class berdasarkan parameter yang telah dikirim dari routes
         */
        $className = str_replace('_', '', ucwords($className) );
        $classNamespace = '\IDGdashboard\Controllers\\'.$className;
        if ( !class_exists($classNamespace) ) {
            /**
             * validate jika filename ini tidak ada maka tampilkan halaman 404 not found
             */
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }
        
        $getClassName = new $classNamespace();
        $this->filename = $getClassName->filename;
        
        /**
         * buat data yang akan di kirim ke view
         */
        $this->data['userdata']     = $this->user->authData();
        $this->data['avatar']       = $this->user->avatar(
            $this->data['userdata']->picture,
            [
                'class' => 'img-responsive img-rounded',
            ]
        );

        $this->data['sidebarmenu'] = $this->menuBuilder->sidebar_menu();
        $baseTemplate = 'IDGdashboard\Views\Pages\\'.$this->filename;
        return view( $baseTemplate, $this->data );
    }

    /**
     * Fungsi untuk menyediakan Assets CSS dan javascript yang nantinya akan dikirim ke view
     **/
    private function createInitAssets(){
        $data = new InitAssets();

        $outputJs     = '';
        foreach ($data->Js() as $js) {
            $outputJs .= script_tag($js) . "\n\t";
        }
        $this->data['js'] = $outputJs;

        $outputCss     = '';
        foreach ($data->Css() as $css) {
            $outputCss .= link_tag($css) . "\n\t";
        }
        $this->data['css'] = $outputCss;

        return $this->data;
    }


}
