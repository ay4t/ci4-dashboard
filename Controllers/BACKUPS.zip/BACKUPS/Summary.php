<?php 
namespace IDGdashboard\Controllers;

class Summary extends Dashboard
{
    public function __construct() {
        $this->filename     = 'default';
    }
}